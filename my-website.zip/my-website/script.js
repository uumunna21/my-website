document.getElementById("clickBtn").addEventListener("click", function () {
    alert("You clicked the button!");
  });
  